public class StoreCode {
    /*
    Cell food = null;
        for (int i = 0; i < gameState.board.length; i++) {
            for (int j = 0; j < gameState.board[i].length; j++) {
                if (gameState.board[i][j] == SnakeGame.FOOD) {
                    food = new Cell(i, j);
                    System.out.println(food);
                }
            }
        }
        // find the closest cell to the food of the head's neighbors
        Cell closest = food;
        Cell head = gameState.snake.peekFirst();
        int distance = gameState.maxDistance();
        assert head != null;
        for (Cell c : head.neighbors()) {
            if (gameState.isOnBoard(c) && gameState.getValueAt(c) != SnakeGame.SNAKE && c.distance(food) < distance) {
                distance = c.distance(food);
                closest = c;
            }
        }

        // Check if gameState or snake is null
        if (gameState == null || gameState.snake == null || gameState.snake.peekFirst() == null) {
            // visszater alapertelmezett modon fel irannyal, ha headPostiton null
            return new Direction(-1, 0); // Fel irany
        }
        // Snake fej pozicioja
        var headPosition = gameState.snake.peekFirst();
        if (headPosition == null) {
            // visszater alapertelmezett modon fel irannyal, ha headPostiton null
            return new Direction(-1, 0);
        }
        int headX = headPosition.i;
        int headY = headPosition.j;

        // etel legkozelebbi pozicioja
        int targetX = -1;
        int targetY = -1;
        for (int y = 0; y < gameState.board.length; y++) {
            for (int x = 0; x < gameState.board.length; x++) {
                if (gameState.board[y][x] == SnakeGame.FOOD) {
                    targetX = x;
                    targetY = y;
                    break;
                }
            }
        }

        // Ha megtalaljuk az etelt, a megfelelo iranyban mozgunk fele
        if (targetX != -1 && targetY != -1) {
            if (!isObstacleBetween(headX, headY, targetX, targetY)) {
            if (targetX < headX && isSafeMove(new Direction(0, -1))) return new Direction(0, -1); // Bal
            else if (targetX > headX && isSafeMove(new Direction(0, 1))) return new Direction(0, 1); // Jobb
            else if (targetY < headY && isSafeMove(new Direction(-1, 0))) return new Direction(-1, 0); // Fel
            else if (targetY > headY && isSafeMove(new Direction(1, 0))) return new Direction(1, 0); // Le
        } else {
            // Ha az etel es a fej kozott a test van, keresni kell egy biztonsagos utat
            return findSafePathToFood(headX, headY, targetX, targetY);
        }
    }

        // Alapertelmezett a legkozelebbi fele, ha nincs etel vagy nincs biztonsagos ut
        return head.directionTo(closest);

     */
}
