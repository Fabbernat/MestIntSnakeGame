///Fabbernat,Fabian.Bernat@stud.u-szeged.hu
import java.util.Random;
import game.snake.Direction;
import game.snake.SnakeGame;
import game.snake.SnakePlayer;
import game.snake.utils.SnakeGameState;

/**
 * Az Agent osztaly a kigyot vezerlo agens, amely a jatek allapota alapjan 
 * donti el a kovetkezo lepes iranyat. Az agens celja az etel felvetele es a falak,
 * valamint a sajat teste elkerulese.
 */
public class Agent extends game.snake.SnakePlayer {

    // random Veletlenszam-generator az iranyitashoz.
    private final Random random = new Random();

    /**
     * Konstruktor, amely inicializalja az Agent objektumot a megadott jatekkal.
     * @param gameState Az aktualis jatekter allapota.
     * @param color A kigyo szine.
     */
    public Agent(SnakeGameState gameState, int color, Random random) {
        super(gameState, color, random);
    }

    /**
     * Meghatarozza az aktualis jatekallapot alapjan a kovetkezo lepes iranyat.
     * @param remainingTime A hatralevo ido a dontes meghozatalara.
     * @return Az uj irany, amely fele a kigyo mozdul.
     */
    @Override
    public Direction getAction(long remainingTime) {
        // Check if gameState or snake is null
        if (gameState == null || gameState.snake == null || gameState.snake.peekFirst() == null) {
            // visszater alapertelmezett modon fel irannyal, ha headPostiton null
            return new Direction(-1, 0); // Fel irany
        }
        // Snake fej pozicioja
        var headPosition = gameState.snake.peekFirst();
        if (headPosition == null) {
            // visszater alapertelmezett modon fel irannyal, ha headPostiton null
            return new Direction(-1, 0);
        }
        int headX = headPosition.i;
        int headY = headPosition.j;

        // etel legkozelebbi pozicioja
        int targetX = -1;
        int targetY = -1;
        for (int y = 0; y < gameState.board.length; y++) {
            for (int x = 0; x < gameState.board.length; x++) {
                if (gameState.board[y][x] == SnakeGame.FOOD) {
                    targetX = x;
                    targetY = y;
                    break;
                }
            }
        }

        // Ha megtalaljuk az etelt, a megfelelo iranyban mozgunk fele
        if (targetX != -1 && targetY != -1) {
            if (targetX < headX && isSafeMove(new Direction(0, -1))) return new Direction(0, -1); // Bal
            else if (targetX > headX && isSafeMove(new Direction(0, 1))) return new Direction(0, 1); // Jobb
            else if (targetY < headY && isSafeMove(new Direction(-1, 0))) return new Direction(-1, 0); // Fel
            else if (targetY > headY && isSafeMove(new Direction(1, 0))) return new Direction(1, 0); // Le
        }

        // Alapertelmezett random irany, ha nincs etel vagy nincs biztonsagos ut
        Direction[] directions = { new Direction(0, -1), new Direction(0, 1), new Direction(-1, 0), new Direction(1, 0) };
        return directions[random.nextInt(directions.length)];
    }

    /**
     * Ellenorzi, hogy az adott irany biztonsagos-e.
     * @param direction A vizsgalando irany.
     * @return Igaz, ha az irany biztonsagos, hamis kulonben.
     */
    private boolean isSafeMove(Direction direction) {
        assert gameState.snake.peekFirst() != null;
        int nextX = gameState.snake.peekFirst().i + direction.i;
        int nextY = gameState.snake.peekFirst().j + direction.j;

        // Ellenorzi, hogy a lepes hatarokon belul marad-e es elkeruli-e a kigyo testet
        return (nextX >= 0 && nextX < gameState.board.length &&
                nextY >= 0 && nextY < gameState.board.length &&
                gameState.board[nextY][nextX] != SnakeGame.SNAKE);
    }
}